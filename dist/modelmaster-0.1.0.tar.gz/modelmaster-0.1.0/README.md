# ModelMaster

ModelMaster is a Model Management package for model archive including upload and download from AWS S3 and Huggingface Hub.

## Installation

You can install ModelMaster using pip:

```bash
pip install modelmaster

